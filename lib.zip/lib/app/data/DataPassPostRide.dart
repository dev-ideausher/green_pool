class DataPassPostRide {
  String? name;
  String? type;

  DataPassPostRide(this.name, this.type);
}
