import 'package:get/get.dart';
import 'package:green_pool/app/modules/my_rides_one_time/controllers/my_rides_controller.dart';

class RiderMyRidesController extends GetxController {
 // var myRidesModel = Get.find<MyRidesOneTimeController>().myRidesModel;

  // @override
  // void onInit() {
  //   super.onInit();
  // }

  // @override
  // void onReady() {
  //   super.onReady();
  // }

  // @override
  // void onClose() {
  //   super.onClose();
  // }
}
