import 'package:get/get.dart';

class MyRidesRecurringController extends GetxController {
  RxBool isScheduled = false.obs;

  // @override
  // void onInit() {
  //   super.onInit();
  // }

  // @override
  // void onReady() {
  //   super.onReady();
  // }

  // @override
  // void onClose() {
  //   super.onClose();
  // }
}
