import 'package:get/get.dart';

class MyRidesOneTimeController extends GetxController{}